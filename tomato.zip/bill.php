<!DOCTYPE>
<html>
<head>
	<title>BILL</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
	  <style>
  .header {
    background-color: #2456ad;
  }
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #2456ad;
   color: white;
   text-align: center;
}
.card {
  padding:6px; 
}
.card1 {
	width: 40%;
	height: 50%
	text-align:center;
	padding: 2%;
  color: pink;
}
body {
background-color: #373d47;
}
</style>
</head>
<body>
	  <div class="card header">
    <div class="card-body text-center"><b><h3>ORDER</h3></b></div>
  </div>
  <br>
  <br>
  <center>
  	  <div class="card1">
  	<form action="bill1.php" method="post">
	<b>VARIETY1:</b><input type="number" name="v1"><br><br>
	<b>VARIETY2: </b><input type="number" name="v2"><br><br>
  <b>VARIETY3 </b><input type="number" name="v3"><br><br>
   <b>Discount </b><input type="number" name="disc"><br><br>
 
	<input type="submit" class="btn btn-primary" name="submit" value="order">
  <p id="bil"></p>
</form>
  </div>
  </center>
<div class="footer">
  <p>Footer</p>
</div>
</body>
</html>