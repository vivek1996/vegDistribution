<!DOCTYPE html>
<html>
<head>

</head>
<body>
<?php 
session_start();
$con=mysqli_connect('localhost:3306','root','','tomato');
$name=$_GET["uname"];
$sql="SELECT `password` FROM `user` WHERE username='$name'";
if ($result=mysqli_query($con,$sql))
  {
 while ($row=mysqli_fetch_row($result))
    {
    $pass=$row[0];
    if($pass==$_GET["psw"])
    {
    	$_SESSION["uname"] = $name;
    	header('Location: first.php');
    }
    else
    	echo "YOUR PASSWORD WAS WRONG";
    header('Location: first.php');
    }
}
?>
</body>
</html>