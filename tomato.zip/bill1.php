<?php
 $con=mysqli_connect('localhost:3306','root','','tomato');
 $v1=(int)$_POST['v1'];
 $v2=(int)$_POST['v2'];
 $v3=(int)$_POST['v3'];
 $line=;
 $discount=(int)$_POST['disc'];
 $sql = "SELECT * FROM variety_price WHERE date = '2018-07-03'";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    $row = mysqli_fetch_assoc($result);
        $p1=(int)$row['tomato1'];
        $p2=(int)$row['tomato2'];
        $p3=(int)$row['tomato3'];
        
        $x=($v1*$p1);
        $y=($v2*$p2);
        $z=($v3*$p3);
        $price=(int)$x+(int)$y+(int)$z;
        $tot=(int)$price-$discount;

} else {
    echo "0 results";
}
 $sql1="INSERT INTO `order`(`date`, `name`,`line`, `tomato1`, `tomato2`, `tomato3`, `price`, `discount`, `total_amount`) VALUES (now(),'pradee','$line',$v1','$v2','$v3','$price','$discount','$tot')";
  if (mysqli_query($con, $sql1)) {
      header('Location: table.html');
    }
    else {
    echo "Error: wrong user added";
    }
?>
